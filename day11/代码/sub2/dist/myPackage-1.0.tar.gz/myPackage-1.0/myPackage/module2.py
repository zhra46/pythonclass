def welcome():
	print("hello world")