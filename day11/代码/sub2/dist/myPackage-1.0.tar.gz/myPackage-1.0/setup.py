from distutils.core import setup

setup(name="myPackage",version="1.0",descrption="我的第一个模块",author="yjm",py_modules=["myPackage.module1","myPackage.module2"])