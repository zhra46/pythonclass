
import sys
import os
import time

__all__ = ["module1"]
print("init文件")